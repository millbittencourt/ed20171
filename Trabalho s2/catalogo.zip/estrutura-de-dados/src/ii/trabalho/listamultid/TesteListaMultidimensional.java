package ii.trabalho.listamultid;

import static org.junit.Assert.*;
import org.junit.Test;

public class TesteListaMultidimensional {

	@Test
	public void test() {
		ListaMultidimensional lista = new ListaMultidimensional();
		Atores a1 = lista.adicionarAtor("MArcella", 19, "Caximbinha");
		lista.inserirFilme("Marcella", 450, "Drama", 2015, a1, "Romulo Palmeira", "s�rie");
		Filme f1 = lista.buscarFilme("Marcella");
		lista.inserirAtorFilme(f1, "Augusto Sozeau", 39, "Paris");
		lista.inserirAtorFilme(f1, "Marcelle Trateau", 25, "London");

		lista.inserirFilme("melody", 876, "ficc��o", 1987, a1, "Norris", "An ok movie");
		Filme f2 = lista.buscarFilme("melody");
		lista.inserirAtorFilme(f2, "M�rcio", 60, "CidadedeDeus");

		System.out.println("imprimirTodosOsFilmes: ");
		lista.imprimirTodosOsFilmes();

		System.out.println("-------- imprimirTodosOsAtores ---------");
		lista.imprimirTodosOsAtores();
		System.out.println("-------- imprimirFilme ---------");
		lista.imprimirFilme("Marcella");
		System.out.println("-------- imprimirAtoresDoFilme Marcela ---------");
		lista.imprimirAtoresDoFilme("Marcella", "Marcelle Trateau");
		System.out.println("-------- imprimirAtor Augusto ---------");
		lista.imprimirAtor("Augusto Sozeau");

		lista.excluirFilme("Marcella");
		System.out.println("--------imprimirTodosOsFilmes dps de excluir marcella---------");
		lista.imprimirTodosOsFilmes();
		System.out.println("-------imprimirTodosOsAtores dps de excluir marcella-----");
		lista.imprimirTodosOsAtores();
		lista.excluirAtor("Marcelle Trateau");
		System.out.println("---imprimirTodosOsAtores- dps de excluir marcelle------------");
		lista.imprimirTodosOsAtores();
		System.out.println("-----------------");

		assertEquals(true, lista.contemAtor("Augusto Sozeau"));
		assertEquals(false, lista.contemAtor("Marcelle Trateau"));
		// assertEquals(true, lista.contemFilme(4));
		assertEquals(false, lista.contemFilme("MArcella"));
		// assertEquals(true, lista.contemAlunoDisciplina(4, 666));
		// assertEquals(false, lista.contemAlunoDisciplina(4, 333));
	}

}
