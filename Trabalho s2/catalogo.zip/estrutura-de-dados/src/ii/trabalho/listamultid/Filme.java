package ii.trabalho.listamultid;

public class Filme {

	private int ano;
	private String nome;
	private String sinopse;
	private String genero;
	private String diretor;
	private int duracao;
	private Filme prox;
	private Atores atoresPrincipais;

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSinopse() {
		return sinopse;
	}

	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getDiretor() {
		return diretor;
	}

	public void setDiretor(String diretor) {
		this.diretor = diretor;
	}

	public int getDuracao() {
		return duracao;
	}

	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}

	public Filme getProx() {
		return prox;
	}

	public void setProx(Filme prox) {
		this.prox = prox;
	}

	public Atores getAtoresPrincipais() {
		return atoresPrincipais;
	}

	public void setAtoresPrincipais(Atores atoresPrincipais) {
		this.atoresPrincipais = atoresPrincipais;
	}

	public String toString() {
		return "Nome do filme: " + nome + "; G�nero:  " + genero + " ; Dura��o: " + duracao + "; Atores principais: "
				+ atoresPrincipais + "; Ano de produ��o: " + ano + "; Diretor: " + diretor;
	}
}
