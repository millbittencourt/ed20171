package ii.trabalho.listamultid;

public class Atores {

	private String nome;
	private int idade;
	private String cidadeNatal;
	private Atores prox;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getCidadeNatal() {
		return cidadeNatal;
	}

	public void setCidadeNatal(String cidadeNatal) {
		this.cidadeNatal = cidadeNatal;
	}

	public Atores getProx() {
		return prox;
	}

	public void setProx(Atores prox) {
		this.prox = prox;
	}

	public String toString() {
		return "Nome " + nome + " ; Idade: " + idade + "; Cidade natal: " + cidadeNatal;
	}

}
