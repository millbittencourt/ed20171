package ii.trabalho.listamultid;

//Trabalho de Estrutura de Dados 
//Cat�logo de Filmes
//Endryl Marques e Jamille Bittencourt
public class ListaMultidimensional {

	private Filme inicio;

	public void inserirFilme(String nome, int duracao, String genero, int ano, Atores atoresPrincipais, String diretor,
			String sinopse) {
		Filme novo = new Filme();
		novo.setAno(ano);
		novo.setNome(nome);
		novo.setDuracao(duracao);
		novo.setGenero(genero);
		novo.setAtoresPrincipais(atoresPrincipais);
		novo.setDiretor(diretor);
		novo.setSinopse(sinopse);

		novo.setProx(inicio);

		inicio = novo;
	}

	public Atores adicionarAtor(String nome, int idade, String cidadeNatal) {
		Atores novo = new Atores();
		novo.setCidadeNatal(cidadeNatal);
		novo.setIdade(idade);
		novo.setNome(nome);
		return novo;
	}

	public void inserirAtorFilme(Filme filme, String nome, int idade, String cidadeNatal) {
		Atores novo = new Atores();
		novo.setNome(nome);
		novo.setCidadeNatal(cidadeNatal);
		novo.setIdade(idade);
		novo.setProx(filme.getAtoresPrincipais());
		filme.setAtoresPrincipais(novo);
	}

	public void excluirFilme(String nome) {
		if (ehVazia())
			System.out.println("Lista vazia!");
		else {
			Filme ant = null;
			Filme aux = inicio;
			while (aux != null && aux.getNome() != nome) {
				ant = aux;
				aux = aux.getProx();
			}
			if (ant == null) {
				inicio = aux.getProx();
				aux = null;
			} else if (aux.getProx() == null) {
				ant.setProx(null);
				aux = null;
			} else {
				ant.setProx(aux.getProx());
				aux = null;
			}
		}

	}

	public void excluirAtorFilme(String nomeFilme, String nomeAtor) {
		if (ehVazia())
			System.out.println("Lista vazia!");
		else {
			Filme f = buscarFilme(nomeFilme);
			if (f != null && f.getAtoresPrincipais() != null) {
				Atores ant = null;
				Atores aux = f.getAtoresPrincipais();
				while (aux != null && aux.getNome() != nomeAtor) {
					ant = aux;
					aux = aux.getProx();
				}
				if (ant == null) {
					f.setAtoresPrincipais(aux.getProx());
					aux = null;
				} else if (aux.getProx() == null) {
					ant.setProx(null);
					aux = null;
				} else {
					ant.setProx(aux.getProx());
					aux = null;
				}
			}
		}
	}

	public void excluirAtor(String nomeAtor) {
		boolean achou = false;
		if (ehVazia())
			System.out.println("Listas vazias!");
		else {
			Filme aux = inicio;
			while (aux != null && !achou) {
				if (aux.getAtoresPrincipais() != null) {
					Atores ant = null;
					Atores a = aux.getAtoresPrincipais();
					while (a != null && !achou) {
						if (a.getNome() == nomeAtor)
							achou = true;
						else {
							ant = a;
							a = a.getProx();
						}
					}
					if (achou) {
						if (ant == null) {
							aux.setAtoresPrincipais(a.getProx());
							a = null;
						} else if (a.getProx() == null) {
							a.setProx(null);
							aux = null;
						} else {
							ant.setProx(a.getProx());
							aux = null;
						}
					}
				}
				aux = aux.getProx();
			}
			if (!achou)
				System.out.println("Ator n�o encontrado!");
		}
	}

	public boolean contemFilme(String nomeFilme) {
		boolean achou = false;
		if (ehVazia())
			System.out.println("Lista vazia!");
		else {
			Filme aux = inicio;
			while (aux != null && aux.getNome() != nomeFilme)
				aux = aux.getProx();
			if (aux != null)
				achou = true;
		}
		return achou;
	}

	public boolean contemAtor(String nomeAtor) {
		boolean achou = false;
		if (ehVazia())
			System.out.println("Listas vazias!");
		else {
			Filme aux = inicio;
			while (aux != null && !achou) {
				Atores a = buscarAtorFilme(aux.getNome(), nomeAtor);
				if (a != null)
					achou = true;
				aux = aux.getProx();
			}
		}
		return achou;
	}

	public boolean contemAtorFilme(String nomeFilme, String nomeAtor) {
		Atores aux = null;
		if (ehVazia())
			System.out.println("Listas vazias!");
		else {
			Filme f = buscarFilme(nomeFilme);
			if (f.getAtoresPrincipais() != null) {
				aux = f.getAtoresPrincipais();
				while (aux != null && nomeAtor != aux.getNome())
					aux = aux.getProx();
			} else {
				System.out.println("N�o existem atores nesse filme...");
			}
		}
		return aux != null;
	}

	public Atores buscarAtor(String nomeAtor) {
		boolean achou = false;
		Atores a = null;

		if (ehVazia())
			System.out.println("Listas vazias!");
		else {
			Filme aux = inicio;
			while (aux != null && !achou) {
				a = buscarAtorFilme(aux.getNome(), nomeAtor);
				if (a != null)
					achou = true;
				aux = aux.getProx();
			}
		}
		return a;
	}

	public Filme buscarFilme(String nomeFilme) {
		Filme aux = inicio;
		if (ehVazia())
			System.out.println("N�o existem filmes na lista!");
		else {
			while (aux != null && aux.getNome() != nomeFilme)
				aux = aux.getProx();
		}
		return aux;
	}

	// esse eu que fiz
	public Filme buscarFilmePorGenero(String genero) {
		Filme aux = inicio;
		if (ehVazia())
			System.out.println("N�o existem filmes na lista!");
		else {
			while (aux != null && aux.getGenero() != genero)
				aux = aux.getProx();
		}
		return aux;
	}

	public Atores buscarAtorFilme(String nomeFilme, String nomeAtor) {
		Atores aux = null;
		if (ehVazia())
			System.out.println("Listas vazias!");
		else {
			Filme f = buscarFilme(nomeFilme);
			if (f != null && f.getAtoresPrincipais() != null) {
				aux = f.getAtoresPrincipais();
				while (aux != null && aux.getNome() != nomeAtor)
					aux = aux.getProx();
			} else {
				System.out.println("N�o existem atores...");
			}
		}
		return aux;
	}

	public void imprimirFilme(String nomeFilme) {
		Filme f = buscarFilme(nomeFilme);
		if (f != null) {
			System.out.println(f.toString());
		} else {
			System.out.println("Filme n�o encontrado!");
		}
	}

	public void imprimirAtor(String nomeAtor) {
		Atores a = buscarAtor(nomeAtor);
		if (a != null) {
			System.out.println(a.toString());
		} else {
			System.out.println("Ator n�o encontrado.");
		}
	}

	public void imprimirTodosOsFilmes() {
		if (ehVazia())
			System.out.println("Lista vazia!");
		else {
			Filme aux = inicio;
			while (aux != null) {
				System.out.println(aux.toString());
				aux = aux.getProx();
			}
		}
	}

	public void imprimirAtoresDoFilme(String nomeFilme, String nomeAtor) {
		Atores a = buscarAtorFilme(nomeFilme, nomeAtor);
		if (a != null)
			System.out.println(a.toString());
		else
			System.out.println("Atores n�o encontrados!");
	}

	// esse eu q fiz
	public void imprimirFilmesDosAtores(String nomeAtor) {
		Filme f = null;
		;
		Atores a = f.getAtoresPrincipais();
		if (a != null)
			System.out.println(f.getNome());
		else
			System.out.println("Filmes n�o encontrados!");
	}

	public void imprimirTodosOsAtores() {
		if (ehVazia())
			System.out.println("Listas vazias!");
		else {
			Filme aux = inicio;
			while (aux != null) {
				if (aux.getAtoresPrincipais() != null) {
					Atores a = aux.getAtoresPrincipais();
					while (a != null) {
						System.out.println(a.toString());
						a = a.getProx();
					}
				}
				aux = aux.getProx();
			}
		}
	}

	public boolean ehVazia() {
		return inicio == null;
	}

}
